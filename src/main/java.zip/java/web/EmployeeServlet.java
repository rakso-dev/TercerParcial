package web;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.List;
import java.sql.SQLException;
import java.util.stream.Collectors;

import Entities.Employee;
import DB.EmployeeDAO;

@WebServlet(name = "EmployeeServlet", urlPatterns = {"/Employee"})
public class EmployeeServlet extends HttpServlet {

    public void doGet (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        EmployeeDAO dao = new EmployeeDAO();
        try {
            List<Employee> employees = dao.query();//.parallelStream().collect(Collectors.toList());
            request.setAttribute("employees", employees);
            request.getRequestDispatcher("/Employees.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void doPost (HttpServletRequest request, HttpServletResponse response) throws ServletException{

    }
}
